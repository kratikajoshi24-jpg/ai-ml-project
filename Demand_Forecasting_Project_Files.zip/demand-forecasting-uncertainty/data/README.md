# Data

The project generates a reproducible synthetic daily demand dataset by default, so no data download is required. The synthetic data is only for demonstrating the workflow and is not actual Walmart/M5 data.

For a real-data version, use a suitable store-item demand dataset (for example, M5 Forecasting from Kaggle), document its source and access instructions, and ensure its licence/terms permit your intended use. Do not commit large or restricted datasets to the repository.
